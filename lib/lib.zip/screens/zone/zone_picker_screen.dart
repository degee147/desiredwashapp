import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/zone.dart';
import '../../services/api_service.dart';
import '../../providers/auth_provider.dart';

/// Searchable zone list for Port Harcourt.
/// Push this screen and await the result — returns the selected [Zone].
class ZonePickerScreen extends StatefulWidget {
  final String? currentZoneId;

  /// When true, selecting a zone returns it to the caller instead of
  /// saving to the user's profile and navigating home.
  final bool returnOnly;
  const ZonePickerScreen(
      {super.key, this.currentZoneId, this.returnOnly = false});

  @override
  State<ZonePickerScreen> createState() => _ZonePickerScreenState();
}

class _ZonePickerScreenState extends State<ZonePickerScreen> {
  List<Zone> _allZones = [];
  List<Zone> _filtered = [];
  String? _selectedId;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _selectedId = widget.currentZoneId;
    _loadZones();
  }

  Future<void> _loadZones() async {
    setState(() {
      _allZones = portHarcourtZones;
      _filtered = portHarcourtZones;
      _loading = false;
    });
    try {
      // ✅ uses the provider instance which has the auth token
      final zones = await context.read<ApiService>().getZones();
      if (!mounted) return;
      setState(() {
        _allZones = zones;
        _filtered = zones;
      });
    } catch (_) {}
  }

  void _search(String q) {
    setState(() {
      _filtered = _allZones
          .where((z) =>
              z.name.toLowerCase().contains(q.toLowerCase()) ||
              z.area.toLowerCase().contains(q.toLowerCase()))
          .toList();
    });
  }

  Map<String, List<Zone>> get _grouped {
    final map = <String, List<Zone>>{};
    for (final z in _filtered) {
      map.putIfAbsent(z.area, () => []).add(z);
    }
    return map;
  }

  Future<void> _onConfirm() async {
    final zone = _allZones.firstWhere((z) => z.id == _selectedId);

    // Step 1: show confirmation sheet
    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _ZoneConfirmSheet(zone: zone),
    );

    if (confirmed != true || !mounted) return;

    // returnOnly mode — just pop with the zone, don't save to profile
    if (widget.returnOnly) {
      Navigator.pop(context, zone);
      return;
    }

    // Step 2: show loading spinner while saving
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: AppColors.coral),
      ),
    );

    // Step 3: save to backend and sync provider
    try {
      final updatedUser =
          await context.read<ApiService>().saveUserZone(zone.id);
      if (!mounted) return;
      context.read<AuthProvider>().updateLocalUser(updatedUser);
    } catch (e) {
      debugPrint('❌ saveUserZone error: $e');
      if (!mounted) return;
      Navigator.pop(context); // dismiss loader
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to save zone: $e')),
      );
      return;
    }

    if (!mounted) return;
    Navigator.pop(context); // dismiss loader

    // Step 4: go home, clearing the navigation stack
    Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.cardBg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: AppColors.darkText),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Select Your Area',
            style: TextStyle(
                color: AppColors.darkText,
                fontWeight: FontWeight.w800,
                fontSize: 18)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Search bar
          Container(
            color: AppColors.cardBg,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: TextField(
              onChanged: _search,
              decoration: InputDecoration(
                hintText: 'Search area or zone…',
                hintStyle:
                    TextStyle(color: AppColors.warmGray.withOpacity(0.6)),
                prefixIcon:
                    const Icon(Icons.search_rounded, color: AppColors.warmGray),
                filled: true,
                fillColor: AppColors.cream,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),

          // Coming soon notice
          if (_allZones.any((z) => !z.isAvailable))
            Container(
              width: double.infinity,
              color: const Color(0xFFFFF3CD),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, size: 15, color: Color(0xFF856404)),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text('Greyed-out zones are coming soon.',
                        style:
                            TextStyle(fontSize: 12, color: Color(0xFF856404))),
                  ),
                ],
              ),
            ),

          if (_loading)
            const Expanded(
                child: Center(
                    child: CircularProgressIndicator(color: AppColors.coral)))
          else
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 12),
                children: _grouped.entries
                    .map((entry) => _AreaSection(
                          area: entry.key,
                          zones: entry.value,
                          selectedId: _selectedId,
                          onSelect: (z) {
                            if (!z.isAvailable) return;
                            setState(() => _selectedId = z.id);
                          },
                        ))
                    .toList(),
              ),
            ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: _selectedId == null ? null : _onConfirm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.coral,
                    disabledBackgroundColor: AppColors.cream,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18)),
                    elevation: 0,
                  ),
                  child: Text(
                    _selectedId == null
                        ? 'Select an area to continue'
                        : 'Confirm Area',
                    style: TextStyle(
                      color: _selectedId == null
                          ? AppColors.warmGray
                          : Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── CONFIRMATION BOTTOM SHEET ────────────────────────────────────────────────

class _ZoneConfirmSheet extends StatelessWidget {
  final Zone zone;
  const _ZoneConfirmSheet({required this.zone});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.bg,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: AppColors.peach.withOpacity(0.3),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.location_on_rounded,
                color: AppColors.coral, size: 28),
          ),
          const SizedBox(height: 16),
          const Text('Confirm your area',
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: AppColors.darkText)),
          const SizedBox(height: 8),
          Text(zone.name,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.coral)),
          const SizedBox(height: 4),
          Text(zone.area,
              style: const TextStyle(fontSize: 14, color: AppColors.warmGray)),
          if (zone.deliveryFee != null) ...[
            const SizedBox(height: 4),
            Text('Delivery fee: ₦${zone.deliveryFee!.toInt()}',
                style:
                    const TextStyle(fontSize: 13, color: AppColors.warmGray)),
          ],
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context, false),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.cream),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text('Change',
                      style: TextStyle(
                          color: AppColors.darkText,
                          fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.coral,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text('Confirm',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

// ─── AREA SECTION ─────────────────────────────────────────────────────────────

class _AreaSection extends StatelessWidget {
  final String area;
  final List<Zone> zones;
  final String? selectedId;
  final void Function(Zone) onSelect;
  const _AreaSection(
      {required this.area,
      required this.zones,
      required this.selectedId,
      required this.onSelect});

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 6),
            child: Text(area.toUpperCase(),
                style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: AppColors.warmGray,
                    letterSpacing: 1.2)),
          ),
          ...zones.map((zone) {
            final isSelected = zone.id == selectedId;
            final unavailable = !zone.isAvailable;
            return Opacity(
              opacity: unavailable ? 0.4 : 1.0,
              child: GestureDetector(
                onTap: () => onSelect(zone),
                child: Container(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppColors.peach.withOpacity(0.4)
                        : AppColors.cardBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color:
                            isSelected ? AppColors.coral : Colors.transparent,
                        width: 1.5),
                    boxShadow: const [
                      BoxShadow(
                          color: AppColors.shadow,
                          blurRadius: 8,
                          offset: Offset(0, 2))
                    ],
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.location_on_rounded,
                          color:
                              isSelected ? AppColors.coral : AppColors.warmGray,
                          size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(zone.name,
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                    color: unavailable
                                        ? AppColors.warmGray
                                        : AppColors.darkText)),
                            if (unavailable)
                              Text('Coming soon',
                                  style: TextStyle(
                                      fontSize: 11,
                                      color:
                                          AppColors.warmGray.withOpacity(0.7))),
                          ],
                        ),
                      ),
                      if (zone.deliveryFee != null && !unavailable)
                        Text('₦${zone.deliveryFee!.toInt()} delivery',
                            style: const TextStyle(
                                fontSize: 12, color: AppColors.warmGray)),
                      if (isSelected) ...[
                        const SizedBox(width: 8),
                        const Icon(Icons.check_circle_rounded,
                            color: AppColors.coral, size: 20),
                      ],
                    ],
                  ),
                ),
              ),
            );
          }),
        ],
      );
}
